<?php
session_start();

$connection=mysqli_connect("localhost","root","","adminpanel");
if(isset($_POST['registerbtn'] ))
{
    $flightname=$_POST['flightname'];
    $capacity=$_POST['capacity'];

   
        $query="insert into flightinformation(flightname,capacity) values('$flightname',' $capacity')";
        $query_run=mysqli_query($connection,$query);
    
        if($query_run){
                //echo "saved";
                $_SESSION['success']="Flight is added";
                header('Location:flightregister.php');
        }else{
            //echo "not saved";
            $_SESSION['status']="Flight can not be added";
            header('Location:flightregister.php');
    
        }

    }



if(isset($_POST['updatebtn'])){
   
 $id=$_POST['edit_id'];
 $flightname=$_POST['edit_flightname'];
 $capacity=$_POST['edit_capacity'];

 $query="update flightinformation set flightname='$flightname',capacity='$capacity' where id='$id'";
$query_run=mysqli_query($connection,$query);

if($query_run){
    $_SESSION['success']="Your data is Updated";
    header('location:flightregister.php');
}
else{
    $_SESSION['status']="Your data is not Updated";
    header('location:flightregister.php');

}
}


if(isset($_POST['delete_btn'])){
    $id=$_POST['delete_id'];

    $query="delete from flightinformation where id='$id'";
    $query_run=mysqli_query($connection,$query);

    if($query_run){
            $_SESSION['success']="Your data is deleted";
            header('location:flightregister.php');
        }

    else{
        $_SESSION['status']="YOUR DATA IS NOT DELETED";
        header('location:flightregister.php');


    }
}

?>