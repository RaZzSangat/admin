<?php
session_start();

$connection=mysqli_connect("localhost","root","","adminpanel");
if(isset($_POST['registerbtn'] ))
{
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $confirmpassword=$_POST['confirmpassword'];

    if($password===$confirmpassword){
        $query="insert into register(username,email,password) values('$username','$email','$password')";
        $query_run=mysqli_query($connection,$query);
    
        if($query_run){
                //echo "saved";
                $_SESSION['success']="Admin profile added";
                header('Location:register.php');
        }else{
            //echo "not saved";
            $_SESSION['status']="Admin profile not added";
            header('Location:register.php');
    
        }

    }else{
        $_SESSION['status']="Passowrd mismatched";
        header('Location:register.php');

    }

  
}


if(isset($_POST['updatebtn'])){
   
 $id=$_POST['edit_id'];
 $username=$_POST['edit_username'];
 $email=$_POST['edit_email'];
 $password=$_POST['edit_password'];

 $query="update register set username='$username',email='$email',password='$password' where id='$id'";
$query_run=mysqli_query($connection,$query);

if($query_run){
    $_SESSION['success']="Your data is Updated";
    header('location:register.php');
}
else{
    $_SESSION['status']="Your data is not Updated";
    header('location:register.php');

}
}


if(isset($_POST['delete_btn'])){
    $id=$_POST['delete_id'];

    $query="delete from register where id='$id'";
    $query_run=mysqli_query($connection,$query);

    if($query_run){
            $_SESSION['success']="Your data is deleted";
            header('location:register.php');
        }

    else{
        $_SESSION['status']="yOUR DATA IS NOT DELETED";
        header('location:register.php');


    }
}

?>